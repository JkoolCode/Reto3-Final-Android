package com.example.user.reto3_final;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import com.example.user.reto3_final.Entity.PokemonEntity;
import com.example.user.reto3_final.Utility.AdapterDatos;
import java.util.ArrayList;

public class ContenidoActivity extends AppCompatActivity {
    private ArrayList<PokemonEntity> listaPokemon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        //Crear ArrayList para almacenar los datos de los pokemons
        listaPokemon = new ArrayList<PokemonEntity>();

        //Obtener datos de los pokemons
        String nombre[] = getIntent().getStringArrayExtra("nombrepk");
        String tipo[] = getIntent().getStringArrayExtra("tipopk");
        String imagen[] = getIntent().getStringArrayExtra("imgpk");

        //Obtener ListView
        ListView milista = (ListView) findViewById(R.id.milistapokemon);

        PokemonEntity datospokemon;
        for(int i = 0; i < nombre.length; i++){
            datospokemon = new PokemonEntity(nombre[i], tipo[i], imagen[i]);
            listaPokemon.add(datospokemon);
        }

        //Creando el adapter personalizado
        AdapterDatos adapter = new AdapterDatos(this, listaPokemon);
        milista.setAdapter(adapter);
    }

}
