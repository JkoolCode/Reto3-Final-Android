package com.example.user.reto3_final;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.user.reto3_final.Entity.PokemonEntity;
import com.example.user.reto3_final.Service.ApiImplementation;
import java.util.ArrayList;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class MainActivity extends AppCompatActivity {
    private EditText txt_nombre, txt_tipo;
    private Button btn_ingresar;
    private ArrayList<PokemonEntity> listaPokemon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Obtener variables
        txt_nombre = (EditText) findViewById(R.id.txt_nombre);
        txt_tipo = (EditText) findViewById(R.id.txt_tipo);
        btn_ingresar = (Button) findViewById(R.id.btn_ingresar);

        //Crear Lista para almacenar los datos obtenidos del API
        listaPokemon = new ArrayList<PokemonEntity>();

        //Llamando al servicio
        ApiImplementation.getService().getPokemons(new Callback<ArrayList<PokemonEntity>>() {
            @Override
            public void success(ArrayList<PokemonEntity> lista, Response response) {
                for(PokemonEntity p : lista){
                    listaPokemon.add(p);
                }
            }
            @Override
            public void failure(RetrofitError retrofitError) {
                Toast.makeText(MainActivity.this, "Sin internet =(", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void ingresar(View v){
        boolean encontrar = false;

        for(PokemonEntity p : listaPokemon){
            if (txt_nombre.getText().toString().equalsIgnoreCase(p.getNombre()) && txt_tipo.getText().toString().equalsIgnoreCase(p.getTipo())) {
                encontrar = true;
                break;
            }
        }

        if(encontrar){
            String nombres[] = new String[listaPokemon.size()];
            String tipos[] = new String[listaPokemon.size()];
            String imagenes[] = new String[listaPokemon.size()];

            for(int i = 0; i < listaPokemon.size(); i++){
                nombres[i] = listaPokemon.get(i).getNombre();
                tipos[i] = listaPokemon.get(i).getTipo();
                imagenes[i] = listaPokemon.get(i).getImagen();
            }
            Intent i = new Intent (this, ContenidoActivity.class);
            i.putExtra("nombrepk", nombres);
            i.putExtra("tipopk", tipos);
            i.putExtra("imgpk", imagenes);
            startActivity(i);
        }else {
            Toast.makeText(MainActivity.this, "Pokemon no encontrado!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
