package com.example.user.reto3_final.Service;
import com.example.user.reto3_final.Entity.PokemonEntity;
import java.util.ArrayList;
import retrofit.Callback;
import retrofit.http.GET;

public interface ApiService {
    @GET("/lista_pokemons.php")
    void getPokemons(Callback<ArrayList<PokemonEntity>> callback);
}
